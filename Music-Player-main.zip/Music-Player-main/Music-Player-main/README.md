# Music-Player with JavaScript - Henry Orellana

Function                    |       Funcion
1) Random Song              |    1)Canción Aleatoria
2) Previous Song            |     2)Canción anterior
3) Next Song                |      3)Siguiente Cancion 
4) Repeat Song              |       4)Repetir Canción
