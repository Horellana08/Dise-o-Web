const modal = document.getElementById("modal");
const thumbnails = document.querySelectorAll(".thumbnail");
const modalImage = document.querySelector(".modal-content");
const closeBtn = document.querySelector(".close");

thumbnails.forEach(thumbnail => {
    thumbnail.addEventListener("click", () => {
        modal.style.display = "flex";
        modalImage.src = thumbnail.src;
    });
});

closeBtn.addEventListener("click", () => {
    modal.style.display = "none";
});

window.addEventListener("click", event => {
    if (event.target === modal) {
        modal.style.display = "none";
    }
});
